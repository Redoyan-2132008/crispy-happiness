<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Redoyan's Personal Page</title>

    <style>

        body {

            font-family: Arial, sans-serif;

            background-color: beige;

            color: olive;

            margin: 0;

            padding: 0;

        }

        header {

            background-color: olive;

            color: beige;

            text-align: center;

            padding: 20px 0;

        }

        h1 {

            margin: 0;

            font-size: 36px;

        }

        .container {

            padding: 20px;

        }

        .section {

            margin-bottom: 20px;

        }

        .social-links a {

            color: olive;

            text-decoration: none;

            margin-right: 10px;

        }

        .photos {

            display: flex;

            flex-wrap: wrap;

            justify-content: center;

        }

        .photo {

            margin: 10px;

        }

        .photo img {

            max-width: 100%;

            height: auto;

        }

    </style>

</head>

<body>

    <header>

        <h1>Redoyan (Ridu)</h1>

    </header>

    <div class="container">

        <section class="section">

            <h2>About Me</h2>

            <p>I'm Redoyan, also known as Ridu. I'm a student who loves watching movies, series, and listening to music.</p>

        </section>

        <section class="section">

            <h2>Contact Information</h2>

            <ul>

                <li>Email: <a href="mailto:mreduan671@gmail.com">mreduan671@gmail.com</a></li>

                <li>Instagram: <a href="https://www.instagram.com/ridu_da_vinci/">ridu_da_vinci</a></li>

                <li>Facebook: <a href="https://www.facebook.com/RedoyanAeby">Redoyan Aeby</a></li>

            </ul>

        </section>

        <section class="section">

            <h2>Get in Touch</h2>

            <p>Feel free to contact me for movie or series suggestions, or if you need a music playlist!</p>

        </section>

        <section class="section">

            <h2>Social Media</h2>

            <div class="social-links">

                <a href="https://www.instagram.com/ridu_da_vinci/">Instagram</a>

                <a href="https://www.facebook.com/RedoyanAeby">Facebook</a>

            </div>

        </section>

        <section class="section">

            <h2>Photos</h2>

            <div class="photos">

                <div class="photo">

                    <img src="https://via.placeholder.com/300" alt="Photo 1">

                </div>

                <div class="photo">

                    <img src="https://via.placeholder.com/300" alt="Photo 2">

                </div>

                <div class="photo">

                    <i300" alt="Photo 3">

                </div>

            </div>

        </section>

    </div>

</body>

</html>